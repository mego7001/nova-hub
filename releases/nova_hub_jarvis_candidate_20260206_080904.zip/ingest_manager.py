﻿from __future__ import annotations
import os
import shutil
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from core.ingest.file_types import classify_path
from core.ingest.unzip import safe_extract_zip, ZipLimitError
from core.ingest.parsers.text_parser import parse_text
from core.ingest.parsers.pdf_parser import parse_pdf
from core.ingest.parsers.docx_parser import parse_docx
from core.ingest.parsers.xlsx_parser import parse_xlsx
from core.ingest.parsers.image_parser import parse_image
from core.ingest.index_store import IndexStore
from core.security.api_importer import ApiImporter
from core.security.secrets import SecretsManager
from core.projects.manager import ProjectManager


class IngestManager:
    def __init__(self, workspace_root: Optional[str] = None, runner=None, registry=None):
        self.manager = ProjectManager(workspace_root)
        self.runner = runner
        self.registry = registry
        self.secrets = SecretsManager(workspace_root=workspace_root)

    def ingest(self, project_id: str, paths: List[str]) -> Dict[str, Any]:
        if not project_id:
            raise ValueError("project_id required")
        if not paths:
            return {"status": "no_files"}

        proj = self.manager.get_project_paths(project_id)
        docs_root = os.path.join(proj.project_root, "docs")
        extracted_root = os.path.join(proj.project_root, "extracted")
        os.makedirs(docs_root, exist_ok=True)
        os.makedirs(extracted_root, exist_ok=True)

        batch_id = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        batch_dir = os.path.join(docs_root, batch_id)
        os.makedirs(batch_dir, exist_ok=True)

        index_path = os.path.join(proj.project_root, "index.json")
        index = IndexStore(index_path)
        records = index.load()

        errors: List[str] = []
        ingested = 0
        extracted = 0
        imported_keys = 0

        api_importer = ApiImporter(self.secrets, runner=self.runner, registry=self.registry)

        for src in paths:
            if not os.path.exists(src):
                errors.append(f"not found: {src}")
                continue
            base = os.path.basename(src)
            dest = os.path.join(batch_dir, base)
            if os.path.isdir(src):
                errors.append(f"skipped directory: {src}")
                continue
            self._copy_file(src, dest)
            ingested += 1

            ftype = classify_path(dest)
            record = self._base_record(dest, ftype)
            records.append(record)

            if ftype == "zip":
                unzip_dir = os.path.join(batch_dir, "unzipped")
                os.makedirs(unzip_dir, exist_ok=True)
                try:
                    extracted_paths, unzip_errors = safe_extract_zip(dest, unzip_dir)
                    errors.extend(unzip_errors)
                    for up in extracted_paths:
                        up_type = classify_path(up)
                        rec = self._base_record(up, up_type)
                        rec["source_zip"] = dest
                        records.append(rec)
                        extracted += self._parse_and_store(rec, extracted_root)
                except ZipLimitError as e:
                    errors.append(str(e))
                except Exception as e:
                    errors.append(f"zip error: {e}")
                continue

            extracted += self._parse_and_store(record, extracted_root)

            if base.lower() == "api.txt" or ftype == "text":
                try:
                    content = parse_text(dest).get("text", "")
                    detected = api_importer.detect_keys(content)
                    if base.lower() == "api.txt" or len(detected) >= 2:
                        imported_keys += api_importer.import_from_text(content)
                except Exception as e:
                    errors.append(f"api import failed: {e}")

        index.save(records, writer=self._write_text, repo_root=proj.project_root)

        return {
            "status": "ok",
            "batch_id": batch_id,
            "docs_dir": batch_dir,
            "extracted_dir": extracted_root,
            "index_path": index_path,
            "counts": {
                "files_ingested": ingested,
                "files_extracted": extracted,
                "keys_imported": imported_keys,
            },
            "errors": errors,
        }

    def _base_record(self, path: str, ftype: str) -> Dict[str, Any]:
        stat = os.stat(path)
        return {
            "doc_id": uuid.uuid4().hex[:12],
            "stored_path": path,
            "type": ftype,
            "size": stat.st_size,
            "metadata": {},
            "created_at": datetime.utcnow().isoformat() + "Z",
        }

    def _parse_and_store(self, record: Dict[str, Any], extracted_root: str) -> int:
        ftype = record.get("type")
        path = record.get("stored_path")
        if not path or ftype in ("zip", "binary"):
            return 0

        result: Dict[str, Any] = {}
        if ftype == "text":
            result = parse_text(path)
        elif ftype == "pdf":
            result = parse_pdf(path)
        elif ftype == "docx":
            result = parse_docx(path)
        elif ftype == "xlsx":
            result = parse_xlsx(path)
        elif ftype == "image":
            result = parse_image(path)

        record["metadata"] = {k: v for k, v in result.items() if k not in ("text",)}
        text = result.get("text") or ""
        if text:
            out_path = os.path.join(extracted_root, f"{record['doc_id']}.txt")
            self._write_text(out_path, text)
            record["extracted_text_path"] = out_path
            return 1
        record["extracted_text_path"] = ""
        if result.get("error"):
            record["metadata"]["error"] = result.get("error")
        return 0

    def _copy_file(self, src: str, dest: str) -> None:
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        shutil.copy2(src, dest)

    def _write_text(self, path: str, text: str) -> None:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tool = self.registry.tools.get("fs.write_text") if self.registry else None
        if tool and self.runner:
            self.runner.execute_registered_tool(tool, path=path, text=text, target=path)
            return
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)
