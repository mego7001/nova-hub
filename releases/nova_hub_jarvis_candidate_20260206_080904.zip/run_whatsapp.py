﻿import os
import sys
from core.portable.paths import detect_base_dir, ensure_workspace_dirs, default_workspace_dir
from PySide6.QtWidgets import QApplication
from ui.whatsapp.app import WhatsAppWindow


def main() -> int:
    base_dir = detect_base_dir()
    ensure_workspace_dirs(base_dir)
    os.environ["NH_BASE_DIR"] = base_dir
    os.environ["NH_WORKSPACE"] = default_workspace_dir(base_dir)
    os.chdir(base_dir)
    app = QApplication(sys.argv)
    window = WhatsAppWindow(project_root=base_dir)
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
