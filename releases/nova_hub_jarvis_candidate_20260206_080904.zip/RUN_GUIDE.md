# Run Guide

## Quick Start
1. Launch the app:
   - `python run_whatsapp.py`
2. Create or import a project.
3. Use the chat to request analysis or actions.

## Core Workflow
- Type requests in chat.
- Nova will ask for explicit confirmation before any execution.
- Confirm using the action bar buttons or a clear "yes" response.

## Suggestions
- Open the Suggestions tab.
- Click "Refresh Suggestions" after an Analyze run.
- Use "Confirm Apply" when a diff is ready.

## Jobs
- Use the Jobs tab to run long tasks.
- Jobs pause at safe points and require confirmation to apply diffs.

## Sketch
- Open the Sketch tab.
- Describe a simple shape in Arabic or English (circle, rectangle, line).
- Nova previews the interpretation and asks to confirm.
- Use "Export DXF" from the Sketch tab when ready.

## Voice
- Click "Mic" to record a short voice input (offline-first).
- Edit the transcription if needed, then send.
- Toggle "Speak" to have Nova read replies if offline TTS is available.

## Security
- Run the Security Audit from the Security tab.
- If critical findings exist, Online AI project scope is blocked.

## Online AI
- Online AI is OFF by default.
- Enable it in Settings when needed and approve each call.
