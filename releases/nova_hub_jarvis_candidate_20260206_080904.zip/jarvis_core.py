from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import hashlib
import re
from typing import Any, Dict, Optional, Tuple

from core.conversation.intent_parser import parse_intent_soft


@dataclass
class IntentResult:
    intent_type: str
    confidence: str
    needs_confirm: bool
    proposed_action: Dict[str, Any]
    conflict: bool
    topic_hash: str
    risk_signal: str


def _hash_topic(text: str) -> str:
    val = (text or "").strip().lower()
    return hashlib.sha256(val.encode("utf-8")).hexdigest()[:16]


def _get_jarvis_state(context: Dict[str, Any]) -> Dict[str, Any]:
    return dict((context or {}).get("jarvis") or {})


def _conflicts_with_goal(message: str, pinned_goal: str) -> bool:
    if not pinned_goal:
        return False
    low = (message or "").lower()
    conflict_terms = [
        "ignore",
        "forget",
        "skip",
        "drop",
        "cancel",
        "delete",
        "remove",
        "تجاهل",
        "انس",
        "سيب",
        "الغاء",
        "إلغاء",
    ]
    return any(t in low for t in conflict_terms)


def _risk_from_intent(intent_type: str) -> str:
    if intent_type in ("apply", "pipeline", "execute"):
        return "high"
    if intent_type in ("verify",):
        return "medium"
    return "low"


def assess_intent(message: str, context: Dict[str, Any]) -> IntentResult:
    intent = parse_intent_soft(message)
    intent_type = str(intent.get("intent") or "unknown")
    confidence = str(intent.get("confidence") or "NONE")
    pinned_goal = str((_get_jarvis_state(context).get("pinned_goal") or "")).strip()
    conflict = _conflicts_with_goal(message, pinned_goal)
    proposed_action = _action_from_intent(intent)
    needs_confirm = bool(proposed_action) and confidence == "HIGH" and not conflict
    topic_hash = _hash_topic(f"{intent_type}:{message}")
    risk_signal = _risk_from_intent(intent_type)
    return IntentResult(
        intent_type=intent_type,
        confidence=confidence,
        needs_confirm=needs_confirm,
        proposed_action=proposed_action,
        conflict=conflict,
        topic_hash=topic_hash,
        risk_signal=risk_signal,
    )


def generate_reply(message: str, context: Dict[str, Any]) -> str:
    # Simple, natural reply (Egyptian Arabic tone) when no stronger guidance applies.
    text = (message or "").strip()
    if not text:
        return "أنا معاك. قولي محتاج إيه بالظبط؟"
    intent = parse_intent_soft(text)
    if intent.get("intent") in ("analyze", "search", "verify", "plan", "apply", "pipeline", "execute"):
        return "تمام. أقدر أبدأ بعد تأكيدك."
    return "تمام. تحب أساعدك إزاي؟"


def manage_disagreement(context: Dict[str, Any], proposal: Dict[str, Any], user_preference: str = "") -> Tuple[str, str]:
    jarvis = _get_jarvis_state(context)
    goal = str(jarvis.get("pinned_goal") or "").strip()
    reason = f"ده متعارض مع الهدف المثبّت: {goal}." if goal else "ده مخالف للتوجيه الحالي."
    disagree = f"أنا مش موافق. {reason}"
    question = "تحب نكمّل في اتجاهك ولا نعدّل المسار؟"
    return disagree, question


def warning_level(context: Dict[str, Any], risk_signal: Dict[str, Any] | str) -> int:
    jarvis = _get_jarvis_state(context)
    state = dict(jarvis.get("warning_state") or {})
    prev_level = int(state.get("level") or 0)
    last_hash = str(state.get("last_topic_hash") or "")
    count = int(state.get("count") or 0)

    if isinstance(risk_signal, dict):
        topic_hash = str(risk_signal.get("topic_hash") or "")
        insist = bool(risk_signal.get("insist"))
        risky = bool(risk_signal.get("risky", True))
    else:
        topic_hash = ""
        insist = False
        risky = bool(risk_signal)

    if not risky:
        return 0

    if topic_hash and topic_hash != last_hash:
        prev_level = 0
        count = 0

    if prev_level == 0:
        level = 1
    elif insist:
        level = min(prev_level + 1, 3)
    else:
        level = prev_level

    state.update({
        "level": level,
        "last_topic_hash": topic_hash or last_hash,
        "count": count + (1 if insist else 0),
    })
    jarvis["warning_state"] = state
    context["jarvis"] = jarvis
    return level


def warning_text(level: int) -> str:
    if level == 1:
        return "تنبيه منطقي: الإجراء ده ممكن يسبب مخاطرة. تحب نكمل ولا نراجع؟"
    if level == 2:
        return "تنبيه بصيغة سيناريو: لو كملنا كده ومشكلة حصلت، هنخسر وقت في تصحيحها بعدين."
    if level >= 3:
        return "تنبيه مختصر: القرار تم رغم مخاطرة موضّحة سابقًا."
    return ""


def documentary_log_note() -> str:
    return "سأسجّل إن القرار تم رغم مخاطرة موضّحة سابقًا."


def record_documentary_warning(context: Dict[str, Any], audit: Any | None = None) -> None:
    note = documentary_log_note()
    jarvis = _get_jarvis_state(context)
    jarvis["last_documentary_note"] = {
        "text": note,
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }
    context["jarvis"] = jarvis
    if audit and hasattr(audit, "emit"):
        try:
            audit.emit("jarvis_documentary_warning", {"note": note})
        except Exception:
            pass


def recovery_mode(context: Dict[str, Any], failure_event: Dict[str, Any]) -> Tuple[str, str]:
    ftype = str((failure_event or {}).get("type") or "unknown")
    if ftype in ("verify_failed", "patch_apply_failed", "pipeline_failed"):
        plan = "خلّينا نصلّح الأول بخطة آمنة (plan فقط)، وبعدها نرجّع التحقق."
    elif ftype in ("preview_crashed",):
        plan = "خلّينا نثبت السبب: هنراجع اللوج ونعدّل أقل تغيير ممكن ثم نجرب تاني."
    else:
        plan = "خلّينا نبدأ بإصلاح آمن وخطوة بخطوة."
    reminder = "بالمناسبة، النتيجة دي كانت ضمن السيناريو اللي اتذكر قبل كده."
    return plan, reminder


def update_last_disagreement(context: Dict[str, Any], topic_hash: str, reason: str) -> None:
    jarvis = _get_jarvis_state(context)
    jarvis["last_disagreement"] = {
        "topic_hash": topic_hash,
        "reason": reason,
        "asked_at": datetime.utcnow().isoformat() + "Z",
    }
    context["jarvis"] = jarvis


def update_last_outcome(context: Dict[str, Any], outcome_type: str, resolved: bool = False) -> None:
    jarvis = _get_jarvis_state(context)
    jarvis["last_outcome"] = {
        "type": outcome_type,
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "resolved": bool(resolved),
    }
    context["jarvis"] = jarvis


def _action_from_intent(intent: Dict[str, Any]) -> Dict[str, Any]:
    action = {"type": intent.get("intent"), "description": ""}
    if intent.get("intent") == "analyze":
        action["description"] = "Analyze the current project"
    elif intent.get("intent") == "search":
        action["description"] = "Find hotspots (TODO/FIXME)"
    elif intent.get("intent") == "verify":
        action["description"] = "Run verification checks"
    elif intent.get("intent") == "plan":
        goal = intent.get("goal") or ""
        action["description"] = "Plan fixes" + (f" for: {goal}" if goal else "")
        action["goal"] = goal
    elif intent.get("intent") == "apply":
        diff_path = intent.get("diff_path") or ""
        action["description"] = "Apply planned diff" + (f": {diff_path}" if diff_path else "")
        action["diff_path"] = diff_path
    elif intent.get("intent") == "pipeline":
        goal = intent.get("goal") or ""
        action["description"] = "Run pipeline" + (f" for: {goal}" if goal else "")
        action["goal"] = goal
    elif intent.get("intent") == "execute":
        num = intent.get("number") or ""
        action["description"] = f"Execute suggestion {num}"
        action["number"] = num
    else:
        return {}
    return action


def is_user_insisting(message: str) -> bool:
    low = (message or "").lower()
    return any(k in low for k in ["proceed", "continue", "go ahead", "كمل", "كمّل", "استمر", "امشي"])


def is_user_adjusting(message: str) -> bool:
    low = (message or "").lower()
    return any(k in low for k in ["adjust", "change", "modify", "عدّل", "غير", "تعديل", "نعدّل"])
