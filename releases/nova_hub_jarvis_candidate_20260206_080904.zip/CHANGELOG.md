# Changelog

## Jarvis Core
- Added Jarvis Core disagreement protocol with a single clarifying question before changing direction.
- Added graduated warnings (levels 1-3) with documentary logging on proceed-anyway decisions.
- Added Recovery Mode messaging for verify/apply/pipeline/preview failures with a calm reminder after stabilization.
- Added per-project Jarvis state persistence (warnings, last disagreement, last outcome).
- Added `scripts/jarvis_core_qa.py` and QA reports in `reports/jarvis_core_qa.*`.

## Sketch
- Added 2D sketch parser, store, renderer, and DXF export.
- Added Sketch tab and chat preview/confirm flow.
- Added `scripts/sketch_qa.py` and QA reports in `reports/sketch_qa.*`.

## Voice
- Added offline-first voice recording and TTS integration with graceful degradation.
- Added mic button and speaker toggle in WhatsApp UI.
- Added `scripts/voice_qa.py` and QA reports in `reports/voice_qa.*`.

## Timeline
- Added per-project audit spine and Timeline tab with filters.
- Added `scripts/timeline_qa.py` and QA reports in `reports/timeline_qa.*`.
