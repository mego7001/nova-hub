# Verify Smoke Report

Timestamp: 2026-02-06T06:05:53.016055Z
Target Root: C:\Users\Victus\Downloads\nova_hub_v1_release\nova_hub

## Checks
- failed: python -m compileall C:\Users\Victus\Downloads\nova_hub_v1_release\nova_hub
- success: python main.py --list-tools

## Recommendation
- Fix failing checks and re-run verify.smoke.
