﻿from __future__ import annotations
from typing import Dict


def parse_pdf(path: str) -> Dict:
    try:
        import fitz  # PyMuPDF
    except Exception:
        return {"text": "", "error": "PyMuPDF not installed"}
    try:
        doc = fitz.open(path)
        parts = []
        for page in doc:
            parts.append(page.get_text("text"))
        return {"text": "\n".join(parts), "error": None, "pages": doc.page_count}
    except Exception as e:
        return {"text": "", "error": str(e)}
