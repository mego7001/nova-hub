import os
import sys
import inspect
from typing import get_args, get_origin
from pathlib import Path

def _load_dotenv(path: str = ".env") -> None:
    p = Path(path)
    if not p.exists():
        return
    for line in p.read_text(encoding="utf-8").splitlines():
        s = line.strip()
        if not s or s.startswith("#") or "=" not in s:
            continue
        k, v = s.split("=", 1)
        k = k.strip()
        v = v.strip().strip('"').strip("'")
        if k and k not in os.environ:
            os.environ[k] = v

_load_dotenv()

from core.plugin_engine.registry import PluginRegistry
from core.plugin_engine.loader import PluginLoader
from core.permission_guard.tool_policy import ToolPolicy
from core.permission_guard.approval_flow import ApprovalFlow
from core.task_engine.runner import Runner

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))

def approval_callback(req, res):
    print("\n=== APPROVAL REQUIRED ===")
    print("ToolGroup:", req.tool_group)
    print("Op:", req.op)
    print("Target:", req.target)
    print("Reason:", res.reason)
    print("Risk:", res.risk_score)
    ans = input("Approve? (y/n): ").strip().lower()
    return ans == "y"

def _prompt_bool(label: str, default: bool | None) -> bool | None:
    hint = "y/n"
    if default is not None:
        hint = f"y/n (default {str(default).lower()})"
    while True:
        s = input(f"{label} [{hint}]: ").strip().lower()
        if not s and default is not None:
            return default
        if s in ("y", "yes"):
            return True
        if s in ("n", "no"):
            return False
        if not s and default is None:
            return None
        print("Please enter y or n.")

def _parse_value(raw: str, ann, default):
    if ann is inspect._empty:
        return raw

    origin = get_origin(ann)
    args = get_args(ann)

    if origin is list or ann is list:
        if not raw.strip():
            return default if default is not inspect._empty else []
        return [x.strip() for x in raw.split(",") if x.strip()]

    if origin is not None and args:
        if any(get_origin(a) is list or a is list for a in args):
            if not raw.strip():
                return default if default is not inspect._empty else []
            return [x.strip() for x in raw.split(",") if x.strip()]

    if ann is int:
        return int(raw)
    if ann is float:
        return float(raw)
    if ann is bool:
        return raw.strip().lower() in ("y", "yes", "true", "1")
    return raw

def _prompt_for_params(handler):
    sig = inspect.signature(handler)
    kwargs = {}
    for name, param in sig.parameters.items():
        if param.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
            continue
        if name == "self":
            continue
        required = param.default is inspect._empty or (param.annotation is str and param.default == "")
        ann = param.annotation
        default = param.default

        if ann is bool:
            val = _prompt_bool(name, None if required else default)
            if val is None and not required:
                continue
            if val is None and required:
                print("This value is required.")
                val = _prompt_bool(name, None)
            kwargs[name] = val
            continue

        prompt = f"{name}"
        if not required:
            prompt += f" (default {default})"
        prompt += ": "
        while True:
            raw = input(prompt).strip()
            if not raw and not required:
                break
            if not raw and required:
                print("This value is required.")
                continue
            try:
                kwargs[name] = _parse_value(raw, ann, default)
                break
            except Exception:
                print("Invalid value. Try again.")
    return kwargs

def _print_preview(tool, target):
    print("\n=== EXECUTION PREVIEW ===")
    print("Tool:", tool.tool_id)
    print("Group:", tool.tool_group)
    print("Op:", tool.op)
    print("Target:", target)

def main():
    if "--list-tools" in sys.argv:
        registry = PluginRegistry()
        PluginLoader(PROJECT_ROOT).load_enabled(os.path.join(PROJECT_ROOT, "configs", "plugins_enabled.yaml"), registry)
        tools = sorted(registry.list_tools(), key=lambda t: t.tool_id)
        for i, t in enumerate(tools, 1):
            print(f"{i:02d}) {t.tool_id:22s} [{t.tool_group}] - {t.description}")
        return

    profile = os.environ.get("NH_PROFILE", "engineering")
    tool_policy = ToolPolicy(os.path.join(PROJECT_ROOT, "configs", "tool_policy.yaml"), active_profile=profile)
    approvals = ApprovalFlow(tool_policy, os.path.join(PROJECT_ROOT, "configs", "approvals.yaml"))
    runner = Runner(approval_flow=approvals, approval_callback=approval_callback)

    registry = PluginRegistry()
    PluginLoader(PROJECT_ROOT).load_enabled(os.path.join(PROJECT_ROOT, "configs", "plugins_enabled.yaml"), registry)

    print(f"\nNH profile: {profile}")
    print("Loaded plugins:", [p.plugin_id for p in registry.list_plugins()])

    tools = sorted(registry.list_tools(), key=lambda t: t.tool_id)
    print("\nTools:")
    for i, t in enumerate(tools, 1):
        print(f"{i:02d}) {t.tool_id:22s} [{t.tool_group}] - {t.description}")

    while True:
        choice = input("\nSelect tool number (or q): ").strip().lower()
        if choice == "q":
            break
        if not choice.isdigit() or not (1 <= int(choice) <= len(tools)):
            print("Invalid choice.")
            continue

        tool = tools[int(choice) - 1]
        try:
            if tool.tool_id == "nesting.solve_rectangles":
                print("Enter rectangles as: w,h;w,h;w,h  (mm)")
                s = input("rects: ").strip()
                rects = []
                if s:
                    for item in s.split(";"):
                        item = item.strip()
                        if not item:
                            continue
                        w, h = item.split(",")
                        rects.append([float(w), float(h)])
                else:
                    # sensible demo set
                    rects = [[300,200],[500,300],[200,200],[800,400],[350,250]]
                target = tool.default_target
                _print_preview(tool, target)
                out = runner.execute_registered_tool(tool, rects=rects, target=target)

            elif tool.tool_id == "conical.generate_helix":
                # allow quick override
                s = input("turns (blank=default): ").strip()
                turns = float(s) if s else None
                target = tool.default_target
                _print_preview(tool, target)
                out = runner.execute_registered_tool(tool, turns=turns, target=target)

            elif tool.tool_id == "halftone.generate_pattern":
                target = tool.default_target
                _print_preview(tool, target)
                out = runner.execute_registered_tool(tool, target=target)

            if tool.tool_id == "fs.write_text":
                p = input(f"Path (default {tool.default_target}): ").strip() or tool.default_target
                txt = input("Text: ").strip()
                _print_preview(tool, p)
                out = runner.execute_registered_tool(tool, path=p, text=txt, target=p)
            else:
                # default call (no extra args)
                if 'out' not in locals():
                    kwargs = _prompt_for_params(tool.handler)
                    target = kwargs.get("target") or tool.default_target
                    _print_preview(tool, target)
                    out = runner.execute_registered_tool(tool, target=target, **kwargs)

            print("\n--- RESULT ---")
            print(out)
        except Exception as e:
            print("\n--- ERROR ---")
            print(str(e))

if __name__ == "__main__":
    main()
