import os
import sys

from PySide6.QtWidgets import QApplication

from ui.dashboard.app import DashboardWindow


def main() -> int:
    app = QApplication(sys.argv)
    window = DashboardWindow(project_root=os.path.dirname(os.path.abspath(__file__)))
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
