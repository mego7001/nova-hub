from __future__ import annotations
import os
from typing import Any, Dict, List, Optional
from core.security.secrets import SecretsManager
from core.llm.online_policy import decide_online, OnlineDecision


class LLMRouter:
    def __init__(self, runner=None, registry=None, config: Optional[Dict[str, Any]] = None):
        self.runner = runner
        self.registry = registry
        self.config = config or {}
        self.task_map = {
            "conversation": self._default_provider(),
            "summarize_docs": "gemini",
            "deep_reasoning": "deepseek",
            "patch_planning": "auto",
        }
        self.fallbacks = ["deepseek", "gemini"]

    def route(
        self,
        task_type: str,
        prompt: str,
        system: Optional[str] = None,
        online_enabled: bool = False,
        project_id: str = "",
        offline_confidence: str = "high",
        extracted_text_len: int = 0,
        parser_ok: bool = True,
        plan_ok: bool = True,
        goal_complex: Optional[bool] = None,
    ) -> Dict[str, Any]:
        provider = self._pick_provider(task_type)
        order = self._build_provider_order(provider)

        decision = decide_online(
            task_type=task_type,
            user_msg=prompt,
            offline_confidence=offline_confidence,
            extracted_text_len=extracted_text_len,
            parser_ok=parser_ok,
            plan_ok=plan_ok,
            goal_complex=goal_complex,
        )

        if not decision.need_online:
            return {
                "mode": "offline",
                "provider": "local",
                "text": "",
                "raw": None,
                "used_fallback": True,
                "error": None,
                "need_online": False,
                "reason": decision.reason,
            }

        if not online_enabled or not self.runner or not self.registry:
            # Stay offline and suggest enabling online if needed
            return {
                "mode": "offline",
                "provider": "local",
                "text": f"Online AI is required for this request ({decision.reason}). Enable Online AI to proceed.",
                "raw": None,
                "used_fallback": True,
                "error": None,
                "need_online": True,
                "reason": decision.reason,
            }

        redacted_prompt = SecretsManager.redact_text(prompt)
        redacted_system = SecretsManager.redact_text(system or "")
        chars = len(redacted_prompt)
        tokens_est = max(1, chars // 4)
        purpose = task_type
        last_error = None
        for p in order:
            try:
                return self._call_provider(
                    p,
                    redacted_prompt,
                    redacted_system,
                    purpose=purpose,
                    project_id=project_id,
                    chars=chars,
                    tokens_est=tokens_est,
                    online_reason=decision.reason,
                )
            except Exception as e:
                last_error = str(e)
                continue

        return {
            "mode": "offline",
            "provider": provider,
            "text": "",
            "raw": None,
            "used_fallback": True,
            "error": last_error,
            "need_online": True,
            "reason": decision.reason,
        }

    def _default_provider(self) -> str:
        return str(self.config.get("default_provider") or os.environ.get("NH_DEFAULT_LLM") or "auto")

    def _pick_provider(self, task_type: str) -> str:
        return str(self.task_map.get(task_type, "auto"))

    def _build_provider_order(self, provider: str) -> List[str]:
        if provider == "auto":
            return list(self.fallbacks)
        if provider in self.fallbacks:
            return [provider] + [p for p in self.fallbacks if p != provider]
        return list(self.fallbacks)

    def _call_provider(
        self,
        provider: str,
        prompt: str,
        system: Optional[str],
        purpose: str,
        project_id: str,
        chars: int,
        tokens_est: int,
        online_reason: str = "",
    ) -> Dict[str, Any]:
        reason = online_reason.replace("\n", " ").strip()
        reason_part = f" reason={reason}" if reason else ""
        target = f"llm:{provider} purpose={purpose} project={project_id or 'unknown'} chars={chars} tokens={tokens_est}{reason_part}"
        if provider == "deepseek":
            tool = self.registry.tools.get("deepseek.chat")
            if not tool:
                raise RuntimeError("deepseek.chat tool not available")
            original = tool.default_target
            tool.default_target = target
            try:
                res = self.runner.execute_registered_tool(tool, prompt=prompt, system=system)
            finally:
                tool.default_target = original
            return {
                "mode": "online",
                "provider": provider,
                "text": _extract_deepseek_text(res),
                "raw": res,
                "used_fallback": False,
                "error": None,
            }
        if provider == "gemini":
            tool = self.registry.tools.get("gemini.prompt")
            if not tool:
                raise RuntimeError("gemini.prompt tool not available")
            original = tool.default_target
            tool.default_target = target
            try:
                res = self.runner.execute_registered_tool(tool, text=prompt, system=system)
            finally:
                tool.default_target = original
            return {
                "mode": "online",
                "provider": provider,
                "text": _extract_gemini_text(res),
                "raw": res,
                "used_fallback": False,
                "error": None,
            }
        raise RuntimeError("Unknown provider")


def _extract_deepseek_text(res: Dict[str, Any]) -> str:
    try:
        choices = res.get("choices") or []
        if choices:
            msg = choices[0].get("message") or {}
            return str(msg.get("content") or "").strip()
    except Exception:
        pass
    return ""


def _extract_gemini_text(res: Dict[str, Any]) -> str:
    try:
        candidates = res.get("candidates") or []
        if candidates:
            content = candidates[0].get("content") or {}
            parts = content.get("parts") or []
            if parts:
                return str(parts[0].get("text") or "").strip()
    except Exception:
        pass
    return ""
