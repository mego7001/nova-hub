﻿from __future__ import annotations
from typing import Dict


def parse_image(path: str) -> Dict:
    try:
        from PIL import Image
    except Exception:
        return {"metadata": {}, "error": "Pillow not installed"}
    try:
        with Image.open(path) as img:
            meta = {
                "format": img.format,
                "mode": img.mode,
                "size": list(img.size),
            }
        return {"metadata": meta, "error": None}
    except Exception as e:
        return {"metadata": {}, "error": str(e)}
