# Roadmap

## Short Term
- Improve Arabic sketch parsing (constraints, dimensions, offsets).
- Add safer preview modes for larger jobs.
- Expand Timeline filters and export options.

## Mid Term
- 3D preview panel with basic solids and constraints.
- CAD kernel integration for precise geometry.
- Voice streaming and push-to-talk improvements.

## Long Term
- Parametric modeling with constraints solver.
- Multi-user collaboration and audit export.
