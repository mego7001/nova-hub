from __future__ import annotations
import os
import zipfile
from typing import List, Tuple


class ZipLimitError(ValueError):
    pass


def safe_extract_zip(zip_path: str, dest: str, max_files: int = 500, max_total_bytes: int = 50_000_000) -> Tuple[List[str], List[str]]:
    if not os.path.isfile(zip_path):
        raise FileNotFoundError("Zip file not found")
    extracted: List[str] = []
    errors: List[str] = []
    total = 0
    with zipfile.ZipFile(zip_path, "r") as zf:
        names = zf.namelist()
        if len(names) > max_files:
            raise ZipLimitError("Zip contains too many files")
        for member in names:
            info = zf.getinfo(member)
            total += info.file_size
            if total > max_total_bytes:
                raise ZipLimitError("Zip exceeds total size limit")
            target = os.path.abspath(os.path.join(dest, member))
            if not target.startswith(os.path.abspath(dest) + os.sep):
                errors.append(f"zip-slip blocked: {member}")
                continue
            if member.endswith("/"):
                os.makedirs(target, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with zf.open(member) as src, open(target, "wb") as out:
                out.write(src.read())
            extracted.append(target)
    return extracted, errors
