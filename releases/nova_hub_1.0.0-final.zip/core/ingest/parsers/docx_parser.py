from __future__ import annotations
from typing import Dict


def parse_docx(path: str) -> Dict:
    try:
        import docx  # python-docx
    except (OSError, ValueError, TypeError, KeyError, AttributeError, RuntimeError):
        return {"text": "", "error": "python-docx not installed"}
    try:
        doc = docx.Document(path)
        parts = [p.text for p in doc.paragraphs if p.text]
        return {"text": "\n".join(parts), "error": None}
    except (OSError, ValueError, TypeError, KeyError, AttributeError, RuntimeError) as e:
        return {"text": "", "error": str(e)}
