import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import QtQuick.Window
import "components"
import "../common_ui" as Common

Window {
    id: win

    visible: true
    visibility: Window.Maximized
    width: 1440
    height: 900
    minimumWidth: 980
    minimumHeight: 640
    color: "transparent"
    title: "Nova HUD V2"
    flags: Qt.Window | Qt.FramelessWindowHint

    property string statusState: "idle"
    property bool waitingAssistant: false
    property string activeDrawer: "tools"
    property bool showIpcHint: false
    property var voiceDevices: ["default"]
    property string voiceDeviceSelected: "default"
    property bool controllerReady: hudController !== null && hudController !== undefined
    property string _lastToastText: ""
    property double _lastToastAtMs: 0

    Common.Theme {
        id: theme
    }

    function _ipcDisabled() {
        if (!win.controllerReady)
            return true
        var summary = String(hudController.healthStatsSummary || "").toLowerCase()
        return summary.indexOf("ipc disabled") >= 0
    }

    function _containsToolTrace(text) {
        var message = String(text || "").toLowerCase()
        return message.indexOf("patch.plan") >= 0 ||
            message.indexOf("patch.apply") >= 0 ||
            message.indexOf("verify") >= 0 ||
            message.indexOf("tool") >= 0
    }

    function _markDoneSoon() {
        statusState = "done"
        doneTimer.restart()
    }

    function _showToast(text) {
        var msg = String(text || "").trim()
        if (!msg)
            return
        var nowMs = Date.now()
        if (msg === win._lastToastText && (nowMs - win._lastToastAtMs) < 1200)
            return
        win._lastToastText = msg
        win._lastToastAtMs = nowMs
        toast.showToast(msg)
    }

    function _appMinimize() {
        win.showMinimized()
        _showToast("Done: Nova minimized")
    }

    function _appClose() {
        win.close()
    }

    function _refreshVoiceDevices() {
        if (!win.controllerReady) {
            voiceDevices = ["default"]
            voiceDeviceSelected = "default"
            return
        }
        var listed = hudController.voice_input_devices()
        if (!listed || listed.length <= 0)
            listed = ["default"]
        voiceDevices = listed
        voiceDeviceSelected = String(hudController.voiceCurrentDevice || "default")
    }

    function _openDrawer(name) {
        activeDrawer = String(name || "tools").toLowerCase()
        if (activeDrawer === "voice")
            _refreshVoiceDevices()
        if (activeDrawer === "history" && win.controllerReady)
            hudController.refresh_timeline()
    }

    function _runPaletteCommand(command) {
        if (!command || !command.actionKind)
            return
        var action = String(command.actionKind || "")
        var isLocalUiOnly = action === "toggle_ipc_hint" || action === "app_minimize" || action === "app_close"
        if (!win.controllerReady && !isLocalUiOnly) {
            _showToast("Controller not ready")
            return
        }

        if (action === "switch_mode") {
            if (hudController && command.payload && command.payload.mode)
                hudController.setTaskMode(command.payload.mode)
            _showToast("Done: switched mode")
            return
        }

        if (action === "open_drawer") {
            var drawerName = command.payload && command.payload.drawer ? command.payload.drawer : "tools"
            _openDrawer(drawerName)
            _showToast("Done: opened drawer")
            return
        }

        if (action === "run_doctor") {
            if (_ipcDisabled()) {
                _showToast("IPC disabled")
                return
            }
            hudController.refreshHealthStats()
            _showToast("Done: doctor report requested")
            return
        }

        if (action === "apply_queue") {
            hudController.queue_apply()
            _showToast("Done: apply candidate queued")
            return
        }

        if (action === "apply_confirm") {
            hudController.confirm_pending()
            _showToast("Done: apply confirm requested")
            return
        }

        if (action === "apply_reject") {
            hudController.reject_pending()
            _showToast("Done: apply rejection requested")
            return
        }

        if (action === "security_audit") {
            hudController.run_security_audit()
            _showToast("Done: security audit started")
            return
        }

        if (action === "refresh_timeline") {
            hudController.refresh_timeline()
            _showToast("Done: timeline refreshed")
            return
        }

        if (action === "voice_toggle") {
            hudController.toggle_voice_enabled()
            _showToast("Done: voice toggled")
            return
        }

        if (action === "voice_mute_toggle") {
            if (hudController.voiceMuted)
                hudController.voice_unmute()
            else
                hudController.voice_mute()
            _showToast("Done: voice mute toggled")
            return
        }

        if (action === "voice_stop") {
            hudController.voice_stop_speaking()
            _showToast("Done: voice output stopped")
            return
        }

        if (action === "voice_replay") {
            hudController.voice_replay_last()
            _showToast("Done: replay requested")
            return
        }

        if (action === "toggle_ipc_hint") {
            showIpcHint = !showIpcHint
            _showToast(showIpcHint ? "Done: IPC hint visible" : "Done: IPC hint hidden")
            return
        }

        if (action === "app_minimize") {
            _appMinimize()
            return
        }

        if (action === "app_close") {
            _showToast("Done: closing Nova")
            _appClose()
        }
    }

    Shortcut {
        sequence: "Ctrl+K"
        onActivated: commandPalette.togglePalette()
    }

    Shortcut {
        sequence: "Esc"
        onActivated: {
            if (commandPalette.visible)
                commandPalette.closePalette()
        }
    }

    Shortcut {
        sequence: "Ctrl+Q"
        onActivated: win._appClose()
    }

    Shortcut {
        sequence: "Ctrl+W"
        onActivated: win._appClose()
    }

    Timer {
        id: runningTimer
        interval: 420
        onTriggered: win._markDoneSoon()
    }

    Timer {
        id: doneTimer
        interval: 1000
        onTriggered: win.statusState = "idle"
    }

    Timer {
        id: errorTimer
        interval: 2000
        onTriggered: win.statusState = "idle"
    }

    Connections {
        target: win.controllerReady ? hudController : null
        ignoreUnknownSignals: true

        function onStatusTextChanged() {
            if (!win.waitingAssistant)
                return
            if (!win.controllerReady)
                return
            var status = String(hudController.statusText || "").toLowerCase()
            if (status.indexOf("fail") >= 0 || status.indexOf("error") >= 0) {
                win.statusState = "error"
                win.waitingAssistant = false
                errorTimer.restart()
            }
        }

        function onVoiceChanged() {
            if (win.activeDrawer === "voice")
                win._refreshVoiceDevices()
        }
    }

    Component.onCompleted: {
        if (win.controllerReady)
            win._refreshVoiceDevices()
    }

    Rectangle {
        anchors.fill: parent
        radius: theme.radiusLg
        color: theme.bgSolid
        border.width: 1
        border.color: theme.borderSoft
        clip: true

        Rectangle {
            anchors.fill: parent
            color: theme.glowSoft
        }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 12
            spacing: 10

            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 92
                radius: theme.radiusMd
                color: theme.bgGlass
                border.width: 1
                border.color: theme.borderHard

                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 10
                    spacing: 4

                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 8

                        Label {
                            Layout.fillWidth: true
                            text: "Nova HUD V2 | " + (win.controllerReady ? hudController.projectBadge : "starting...")
                            color: theme.textPrimary
                            elide: Label.ElideRight
                            font.bold: true
                        }

                        Label {
                            text: "Status: " + (win.controllerReady ? hudController.statusText : "initializing")
                            color: theme.textSecondary
                            font.pixelSize: 12
                            elide: Label.ElideRight
                        }

                        Button {
                            objectName: "hudV2TopMinimizeButton"
                            text: "Minimize"
                            onClicked: win._appMinimize()
                            background: Rectangle {
                                radius: theme.radiusSm
                                color: theme.bgSolid
                                border.width: 1
                                border.color: theme.borderSoft
                            }
                            contentItem: Text {
                                text: parent.text
                                color: theme.textSecondary
                                horizontalAlignment: Text.AlignHCenter
                                verticalAlignment: Text.AlignVCenter
                                font.pixelSize: 11
                                font.bold: true
                            }
                        }

                        Button {
                            objectName: "hudV2TopCloseButton"
                            text: "Close Nova"
                            onClicked: win._appClose()
                            background: Rectangle {
                                radius: theme.radiusSm
                                color: theme.bgSolid
                                border.width: 1
                                border.color: theme.borderSoft
                            }
                            contentItem: Text {
                                text: parent.text
                                color: theme.textSecondary
                                horizontalAlignment: Text.AlignHCenter
                                verticalAlignment: Text.AlignVCenter
                                font.pixelSize: 11
                                font.bold: true
                            }
                        }
                    }

                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 8

                        Label {
                            Layout.fillWidth: true
                            text: win.controllerReady ? hudController.voiceStatusLine : "Voice: unavailable"
                            color: theme.textMuted
                            font.pixelSize: 11
                            elide: Label.ElideRight
                        }

                        Label {
                            text: "Mode: " + (win.controllerReady ? hudController.currentTaskMode : "general")
                            color: theme.textMuted
                            font.pixelSize: 11
                        }

                        Label {
                            text: (win.controllerReady && hudController.hasPendingApproval) ? "Pending: yes" : "Pending: no"
                            color: theme.textMuted
                            font.pixelSize: 11
                        }
                    }

                    Label {
                        Layout.fillWidth: true
                        text: "Capabilities: Chat | Tools | Attach | Health | History | Voice | Security | Timeline"
                        color: theme.textMuted
                        font.pixelSize: 11
                        elide: Label.ElideRight
                    }
                }
            }

            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: showIpcHint ? 30 : 0
                visible: showIpcHint
                radius: theme.radiusSm
                color: theme.bgGlass
                border.width: 1
                border.color: theme.borderSoft

                Label {
                    anchors.fill: parent
                    anchors.margins: 8
                    text: win._ipcDisabled() ? "IPC: disabled" : "IPC: enabled"
                    color: theme.textMuted
                    elide: Label.ElideRight
                    verticalAlignment: Text.AlignVCenter
                }
            }

            RowLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                spacing: 10

                Rectangle {
                    Layout.preferredWidth: 280
                    Layout.minimumWidth: 240
                    Layout.maximumWidth: 320
                    Layout.fillHeight: true
                    radius: theme.radiusMd
                    color: theme.bgGlass
                    border.width: 1
                    border.color: theme.borderSoft

                    ColumnLayout {
                        anchors.fill: parent
                        anchors.margins: 10
                        spacing: 8

                        Label {
                            Layout.fillWidth: true
                            text: "Drawer"
                            color: theme.textPrimary
                            font.bold: true
                        }

                        RowLayout {
                            Layout.fillWidth: true
                            spacing: 6

                            Repeater {
                                model: [
                                    { id: "tools", title: "Tools" },
                                    { id: "attach", title: "Attach" },
                                    { id: "health", title: "Health" },
                                    { id: "history", title: "History" },
                                    { id: "voice", title: "Voice" }
                                ]

                                Button {
                                    required property var modelData
                                    objectName: "hudV2DrawerTab_" + modelData.id

                                    Layout.fillWidth: true
                                    text: modelData.title
                                    onClicked: win._openDrawer(modelData.id)
                                    background: Rectangle {
                                        radius: theme.radiusSm
                                        color: win.activeDrawer === modelData.id ? theme.glowSoft : theme.bgSolid
                                        border.width: 1
                                        border.color: win.activeDrawer === modelData.id ? theme.borderHard : theme.borderSoft
                                    }
                                    contentItem: Text {
                                        text: parent.text
                                        color: theme.textSecondary
                                        horizontalAlignment: Text.AlignHCenter
                                        verticalAlignment: Text.AlignVCenter
                                        font.pixelSize: 11
                                    }
                                }
                            }
                        }

                        Loader {
                            Layout.fillWidth: true
                            Layout.fillHeight: true
                            sourceComponent: {
                                if (win.activeDrawer === "attach")
                                    return attachDrawer
                                if (win.activeDrawer === "health")
                                    return healthDrawer
                                if (win.activeDrawer === "history")
                                    return historyDrawer
                                if (win.activeDrawer === "voice")
                                    return voiceDrawer
                                return toolsDrawer
                            }
                        }
                    }
                }

                ChatPane {
                    id: chatPane
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    theme: theme
                    model: win.controllerReady ? hudController.messagesModel : []
                    busy: win.controllerReady ? hudController.busy : false
                    currentTaskMode: win.controllerReady ? hudController.currentTaskMode : "general"
                    taskModesModel: win.controllerReady ? hudController.taskModesModel : []
                    statusState: win.statusState
                    voiceEnabled: win.controllerReady ? hudController.voiceEnabled : false
                    voiceMuted: win.controllerReady ? hudController.voiceMuted : false
                    voiceState: win.controllerReady ? hudController.voiceState : "idle"
                    voiceStatusLine: win.controllerReady ? hudController.voiceStatusLine : "Voice: unavailable"
                    voiceReplayAvailable: win.controllerReady ? String(hudController.voiceLastSpokenText || "").length > 0 : false
                    onSendRequested: function(message) {
                        if (!win.controllerReady)
                            return
                        win.statusState = "thinking"
                        win.waitingAssistant = true
                        hudController.send_message(message)
                    }
                    onAttachRequested: attachDialog.open()
                    onToolsRequested: {
                        if (win.controllerReady)
                            hudController.toggleToolsMenu()
                    }
                    onTaskModeChangedRequested: function(modeId) {
                        if (win.controllerReady)
                            hudController.setTaskMode(modeId)
                    }
                    onVoiceToggleRequested: {
                        if (win.controllerReady)
                            hudController.toggle_voice_enabled()
                    }
                    onVoiceMuteToggleRequested: {
                        if (!win.controllerReady)
                            return
                        if (hudController.voiceMuted)
                            hudController.voice_unmute()
                        else
                            hudController.voice_mute()
                    }
                    onVoiceStopRequested: {
                        if (win.controllerReady)
                            hudController.voice_stop_speaking()
                    }
                    onVoiceReplayRequested: {
                        if (win.controllerReady)
                            hudController.voice_replay_last()
                    }
                    onVoicePanelRequested: {
                        win._openDrawer("voice")
                        win._showToast("Done: voice panel opened")
                    }
                    onMessageObserved: function(payload) {
                        if (!payload)
                            return
                        var role = String(payload.role || "")
                        if (role !== "assistant")
                            return

                        win.waitingAssistant = false
                        var text = String(payload.text || "")
                        if (win._containsToolTrace(text)) {
                            win.statusState = "running"
                            runningTimer.restart()
                        } else {
                            win._markDoneSoon()
                        }
                    }
                }
            }
        }
    }

    CommandPalette {
        id: commandPalette
        theme: theme
        onCommandTriggered: function(command) {
            win._runPaletteCommand(command)
        }
    }

    Toast {
        id: toast
        theme: theme
        z: 100
    }

    FileDialog {
        id: attachDialog
        title: "Attach Files"
        fileMode: FileDialog.OpenFiles
        onAccepted: {
            if (!win.controllerReady)
                return
            hudController.attachFiles(selectedFiles)
            win._showToast("Done: files attached")
        }
    }

    Component {
        id: toolsDrawer

        ScrollView {
            clip: true

            ColumnLayout {
                width: parent.availableWidth > 0 ? parent.availableWidth : parent.width
                spacing: 8

                Label {
                    Layout.fillWidth: true
                    text: win.controllerReady ? hudController.toolsBadge : "Tools: unavailable"
                    color: theme.textSecondary
                    wrapMode: Label.Wrap
                }

                Label {
                    Layout.fillWidth: true
                    text: win.controllerReady ? hudController.confirmationSummary : ""
                    color: theme.textMuted
                    wrapMode: Label.Wrap
                    visible: win.controllerReady && String(hudController.confirmationSummary || "").length > 0
                }

                Button {
                    objectName: "hudV2ToolsToggleMenuButton"
                    text: "Toggle Tools Menu"
                    onClicked: {
                        if (!win.controllerReady)
                            return
                        hudController.toggleToolsMenu()
                        win._showToast("Done: tools menu toggled")
                    }
                    background: Rectangle {
                        radius: theme.radiusSm
                        color: theme.bgSolid
                        border.width: 1
                        border.color: theme.borderSoft
                    }
                    contentItem: Text {
                        text: parent.text
                        color: theme.textSecondary
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }

                Button {
                    objectName: "hudV2ToolsQueueApplyButton"
                    text: "Queue Apply Candidate"
                    enabled: win.controllerReady && hudController.applyEnabled
                    onClicked: {
                        if (!win.controllerReady)
                            return
                        hudController.queue_apply()
                        win._showToast("Done: apply candidate queued")
                    }
                    background: Rectangle {
                        radius: theme.radiusSm
                        color: theme.bgSolid
                        border.width: 1
                        border.color: theme.borderSoft
                    }
                    contentItem: Text {
                        text: parent.text
                        color: theme.textSecondary
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }

                Button {
                    objectName: "hudV2ToolsConfirmPendingButton"
                    text: "Confirm Pending"
                    enabled: win.controllerReady && hudController.hasPendingApproval && !hudController.confirmationReadOnly && !hudController.confirmationLocked
                    onClicked: {
                        if (!win.controllerReady)
                            return
                        hudController.confirm_pending()
                        win._showToast("Done: pending confirmation sent")
                    }
                    background: Rectangle {
                        radius: theme.radiusSm
                        color: theme.bgSolid
                        border.width: 1
                        border.color: theme.borderSoft
                    }
                    contentItem: Text {
                        text: parent.text
                        color: theme.textSecondary
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }

                Button {
                    objectName: "hudV2ToolsRejectPendingButton"
                    text: "Reject Pending"
                    enabled: win.controllerReady && hudController.hasPendingApproval && !hudController.confirmationReadOnly && !hudController.confirmationLocked
                    onClicked: {
                        if (!win.controllerReady)
                            return
                        hudController.reject_pending()
                        win._showToast("Done: pending rejection sent")
                    }
                    background: Rectangle {
                        radius: theme.radiusSm
                        color: theme.bgSolid
                        border.width: 1
                        border.color: theme.borderSoft
                    }
                    contentItem: Text {
                        text: parent.text
                        color: theme.textSecondary
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }

                Button {
                    objectName: "hudV2ToolsRunSecurityButton"
                    text: "Run Security Audit"
                    onClicked: {
                        if (!win.controllerReady)
                            return
                        hudController.run_security_audit()
                        win._showToast("Done: security audit started")
                    }
                    background: Rectangle {
                        radius: theme.radiusSm
                        color: theme.bgSolid
                        border.width: 1
                        border.color: theme.borderSoft
                    }
                    contentItem: Text {
                        text: parent.text
                        color: theme.textSecondary
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }

                Button {
                    objectName: "hudV2ToolsRefreshTimelineButton"
                    text: "Refresh Timeline"
                    onClicked: {
                        if (!win.controllerReady)
                            return
                        hudController.refresh_timeline()
                        win._showToast("Done: timeline refreshed")
                    }
                    background: Rectangle {
                        radius: theme.radiusSm
                        color: theme.bgSolid
                        border.width: 1
                        border.color: theme.borderSoft
                    }
                    contentItem: Text {
                        text: parent.text
                        color: theme.textSecondary
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }

                Label {
                    Layout.fillWidth: true
                    text: win.controllerReady ? hudController.evidenceChip : "Evidence: n/a"
                    color: theme.textMuted
                    wrapMode: Label.Wrap
                }

                Label {
                    Layout.fillWidth: true
                    text: win.controllerReady ? hudController.actionsChip : "Actions: n/a"
                    color: theme.textMuted
                    wrapMode: Label.Wrap
                }

                Label {
                    Layout.fillWidth: true
                    text: win.controllerReady ? hudController.risksChip : "Risks: n/a"
                    color: theme.textMuted
                    wrapMode: Label.Wrap
                }
            }
        }
    }

    Component {
        id: attachDrawer

        ColumnLayout {
            spacing: 8

            Label {
                Layout.fillWidth: true
                text: win.controllerReady ? hudController.attachLastSummary : "No attachments yet."
                color: theme.textSecondary
                wrapMode: Label.Wrap
            }

            Button {
                objectName: "hudV2AttachChooseFilesButton"
                text: "Choose Files"
                onClicked: {
                    attachDialog.open()
                    win._showToast("Done: attach dialog opened")
                }
                background: Rectangle {
                    radius: theme.radiusSm
                    color: theme.bgSolid
                    border.width: 1
                    border.color: theme.borderSoft
                }
                contentItem: Text {
                    text: parent.text
                    color: theme.textSecondary
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
            }
        }
    }

    Component {
        id: healthDrawer

        ScrollView {
            clip: true

            ColumnLayout {
                width: parent.availableWidth > 0 ? parent.availableWidth : parent.width
                spacing: 8

                Label {
                    Layout.fillWidth: true
                    text: win.controllerReady ? hudController.healthStatsSummary : "Health unavailable."
                    color: theme.textSecondary
                    wrapMode: Label.Wrap
                }

                Rectangle {
                    Layout.fillWidth: true
                    radius: theme.radiusSm
                    color: theme.bgGlass
                    border.width: 1
                    border.color: theme.borderSoft
                    implicitHeight: ollamaHealthColumn.implicitHeight + 14

                    ColumnLayout {
                        id: ollamaHealthColumn
                        anchors.fill: parent
                        anchors.margins: 7
                        spacing: 6

                        Label {
                            Layout.fillWidth: true
                            text: "Local LLM: Ollama"
                            color: theme.textPrimary
                            font.bold: true
                        }

                        Label {
                            Layout.fillWidth: true
                            text: win.controllerReady ? hudController.ollamaHealthSummary : "Ollama status unavailable."
                            color: theme.textSecondary
                            wrapMode: Label.Wrap
                        }

                        RowLayout {
                            Layout.fillWidth: true
                            spacing: 6

                            Button {
                                objectName: "hudV2OllamaRefreshModelsButton"
                                text: "Refresh Models"
                                onClicked: {
                                    if (!win.controllerReady)
                                        return
                                    hudController.refreshOllamaModels()
                                    win._showToast("Done: Ollama models refreshed")
                                }
                                background: Rectangle {
                                    radius: theme.radiusSm
                                    color: theme.bgSolid
                                    border.width: 1
                                    border.color: theme.borderSoft
                                }
                                contentItem: Text {
                                    text: parent.text
                                    color: theme.textSecondary
                                    horizontalAlignment: Text.AlignHCenter
                                    verticalAlignment: Text.AlignVCenter
                                }
                            }

                            ComboBox {
                                id: ollamaModelCombo
                                objectName: "hudV2OllamaModelCombo"
                                Layout.fillWidth: true
                                model: win.controllerReady ? (["default"].concat(hudController.ollamaAvailableModels || [])) : ["default"]

                                function syncIndex() {
                                    var wanted = String(win.controllerReady ? (hudController.ollamaSessionModelOverride || "") : "")
                                    var resolved = wanted.length > 0 ? wanted : "default"
                                    if (!model || model.length <= 0) {
                                        currentIndex = -1
                                        return
                                    }
                                    for (var i = 0; i < model.length; i++) {
                                        if (String(model[i]) === resolved) {
                                            currentIndex = i
                                            return
                                        }
                                    }
                                    currentIndex = 0
                                }

                                onActivated: {
                                    if (!win.controllerReady || !model || currentIndex < 0 || currentIndex >= model.length)
                                        return
                                    var selected = String(model[currentIndex] || "default")
                                    hudController.setOllamaSessionModel(selected)
                                    win._showToast(selected === "default" ? "Done: Ollama model override cleared" : ("Done: Ollama model set to " + selected))
                                }
                                onModelChanged: syncIndex()
                                Component.onCompleted: syncIndex()

                                background: Rectangle {
                                    radius: theme.radiusSm
                                    color: theme.bgSolid
                                    border.width: 1
                                    border.color: theme.borderSoft
                                }
                                contentItem: Text {
                                    text: ollamaModelCombo.displayText
                                    color: theme.textSecondary
                                    leftPadding: 8
                                    verticalAlignment: Text.AlignVCenter
                                    elide: Text.ElideRight
                                    font.pixelSize: 12
                                }
                            }
                        }
                    }
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 6

                    Button {
                        objectName: "hudV2HealthRefreshButton"
                        Layout.fillWidth: true
                        text: "Refresh Health"
                        onClicked: {
                            if (!win.controllerReady)
                                return
                            hudController.refreshHealthStats()
                            win._showToast("Done: health stats refreshed")
                        }
                        background: Rectangle {
                            radius: theme.radiusSm
                            color: theme.bgSolid
                            border.width: 1
                            border.color: theme.borderSoft
                        }
                        contentItem: Text {
                            text: parent.text
                            color: theme.textSecondary
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                        }
                    }

                    Button {
                        objectName: "hudV2HealthDoctorButton"
                        Layout.fillWidth: true
                        text: "Doctor Report"
                        onClicked: {
                            if (win._ipcDisabled()) {
                                win._showToast("IPC disabled")
                                return
                            }
                            if (!win.controllerReady)
                                return
                            hudController.refreshHealthStats()
                            win._showToast("Done: doctor report requested")
                        }
                        background: Rectangle {
                            radius: theme.radiusSm
                            color: theme.bgSolid
                            border.width: 1
                            border.color: theme.borderSoft
                        }
                        contentItem: Text {
                            text: parent.text
                            color: theme.textSecondary
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                        }
                    }
                }

                ListView {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 280
                    clip: true
                    spacing: 6
                    model: win.controllerReady ? hudController.healthStatsModel : []

                    delegate: Rectangle {
                        required property string provider
                        required property string calls
                        required property string success_rate
                        required property string avg_latency_ms

                        width: ListView.view.width
                        radius: theme.radiusSm
                        color: theme.bgSolid
                        border.width: 1
                        border.color: theme.borderSoft
                        implicitHeight: providerInfo.implicitHeight + 14

                        Column {
                            id: providerInfo
                            anchors.fill: parent
                            anchors.margins: 7
                            spacing: 2

                            Label {
                                width: parent.width
                                text: provider + " | calls=" + calls
                                color: theme.textPrimary
                                font.bold: true
                                elide: Label.ElideRight
                            }

                            Label {
                                width: parent.width
                                text: "success=" + success_rate + " | avg latency=" + avg_latency_ms + "ms"
                                color: theme.textMuted
                                font.pixelSize: 11
                                elide: Label.ElideRight
                            }
                        }
                    }
                }
            }
        }
    }

    Component {
        id: historyDrawer

        ScrollView {
            clip: true

            ColumnLayout {
                width: parent.availableWidth > 0 ? parent.availableWidth : parent.width
                spacing: 8

                Label {
                    Layout.fillWidth: true
                    text: win.controllerReady ? hudController.timelineSummary : "No timeline events."
                    color: theme.textSecondary
                    wrapMode: Label.Wrap
                }

                Button {
                    objectName: "hudV2HistoryRefreshButton"
                    text: "Refresh Timeline"
                    onClicked: {
                        if (!win.controllerReady)
                            return
                        hudController.refresh_timeline()
                        win._showToast("Done: timeline refreshed")
                    }
                    background: Rectangle {
                        radius: theme.radiusSm
                        color: theme.bgSolid
                        border.width: 1
                        border.color: theme.borderSoft
                    }
                    contentItem: Text {
                        text: parent.text
                        color: theme.textSecondary
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }

                ListView {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 280
                    clip: true
                    spacing: 6
                    model: win.controllerReady ? hudController.timelineModel : []

                    delegate: Rectangle {
                        required property string event_type
                        required property string recorded_at
                        required property string detail

                        width: ListView.view.width
                        radius: theme.radiusSm
                        color: theme.bgSolid
                        border.width: 1
                        border.color: theme.borderSoft
                        implicitHeight: timelineInfo.implicitHeight + 14

                        Column {
                            id: timelineInfo
                            anchors.fill: parent
                            anchors.margins: 7
                            spacing: 2

                            Label {
                                width: parent.width
                                text: event_type + " | " + recorded_at
                                color: theme.textPrimary
                                font.bold: true
                                elide: Label.ElideRight
                            }

                            Label {
                                width: parent.width
                                text: detail
                                color: theme.textMuted
                                wrapMode: Label.Wrap
                                maximumLineCount: 3
                                elide: Label.ElideRight
                                font.pixelSize: 11
                            }
                        }
                    }
                }

                Label {
                    Layout.fillWidth: true
                    text: win.controllerReady ? hudController.latestReplyPreview : ""
                    color: theme.textSecondary
                    wrapMode: Label.Wrap
                }

                Label {
                    Layout.fillWidth: true
                    text: "Project Status: " + (win.controllerReady ? hudController.projectStatus : "n/a")
                    color: theme.textMuted
                    wrapMode: Label.Wrap
                }
            }
        }
    }

    Component {
        id: voiceDrawer

        ScrollView {
            clip: true

            ColumnLayout {
                width: parent.availableWidth > 0 ? parent.availableWidth : parent.width
                spacing: 8

                Label {
                    Layout.fillWidth: true
                    text: win.controllerReady ? hudController.voiceStatusLine : "Voice: unavailable"
                    color: theme.textSecondary
                    wrapMode: Label.Wrap
                }

                Label {
                    Layout.fillWidth: true
                    text: "Providers: " + (win.controllerReady ? hudController.voiceProviderNames : "n/a")
                    color: theme.textMuted
                    wrapMode: Label.Wrap
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 6

                    Button {
                        objectName: "hudV2VoiceDrawerMicButton"
                        Layout.fillWidth: true
                        text: (win.controllerReady && hudController.voiceEnabled) ? "Mic On" : "Mic Off"
                        enabled: win.controllerReady
                        onClicked: {
                            if (!win.controllerReady)
                                return
                            hudController.toggle_voice_enabled()
                            win._showToast("Done: voice toggled")
                        }
                        background: Rectangle {
                            radius: theme.radiusSm
                            color: (win.controllerReady && hudController.voiceEnabled) ? theme.glowSoft : theme.bgSolid
                            border.width: 1
                            border.color: (win.controllerReady && hudController.voiceEnabled) ? theme.borderHard : theme.borderSoft
                        }
                        contentItem: Text {
                            text: parent.text
                            color: theme.textSecondary
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                            font.bold: true
                        }
                    }

                    Button {
                        objectName: "hudV2VoiceDrawerMuteButton"
                        Layout.fillWidth: true
                        text: (win.controllerReady && hudController.voiceMuted) ? "Unmute" : "Mute"
                        enabled: win.controllerReady && hudController.voiceEnabled
                        onClicked: {
                            if (!win.controllerReady)
                                return
                            if (hudController.voiceMuted)
                                hudController.voice_unmute()
                            else
                                hudController.voice_mute()
                            win._showToast("Done: voice mute toggled")
                        }
                        background: Rectangle {
                            radius: theme.radiusSm
                            color: theme.bgSolid
                            border.width: 1
                            border.color: theme.borderSoft
                        }
                        contentItem: Text {
                            text: parent.text
                            color: theme.textSecondary
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                        }
                    }
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 6

                    Button {
                        objectName: "hudV2VoiceDrawerStopButton"
                        Layout.fillWidth: true
                        text: "Stop Voice"
                        enabled: win.controllerReady && hudController.voiceEnabled
                        onClicked: {
                            if (!win.controllerReady)
                                return
                            hudController.voice_stop_speaking()
                            win._showToast("Done: voice output stopped")
                        }
                        background: Rectangle {
                            radius: theme.radiusSm
                            color: theme.bgSolid
                            border.width: 1
                            border.color: theme.borderSoft
                        }
                        contentItem: Text {
                            text: parent.text
                            color: theme.textSecondary
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                        }
                    }

                    Button {
                        objectName: "hudV2VoiceDrawerReplayButton"
                        Layout.fillWidth: true
                        text: "Replay Last"
                        enabled: win.controllerReady && hudController.voiceEnabled && String(hudController.voiceLastSpokenText || "").length > 0
                        onClicked: {
                            if (!win.controllerReady)
                                return
                            hudController.voice_replay_last()
                            win._showToast("Done: voice replay requested")
                        }
                        background: Rectangle {
                            radius: theme.radiusSm
                            color: theme.bgSolid
                            border.width: 1
                            border.color: theme.borderSoft
                        }
                        contentItem: Text {
                            text: parent.text
                            color: theme.textSecondary
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                        }
                    }
                }

                Label {
                    Layout.fillWidth: true
                    text: "Input Device"
                    color: theme.textSecondary
                    font.bold: true
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 6

                    ComboBox {
                        id: voiceDeviceCombo
                        objectName: "hudV2VoiceDeviceCombo"
                        Layout.fillWidth: true
                        model: win.voiceDevices

                        function syncIndex() {
                            var wanted = String(win.voiceDeviceSelected || "default")
                            if (!model || model.length <= 0) {
                                currentIndex = -1
                                return
                            }
                            for (var i = 0; i < model.length; i++) {
                                if (String(model[i]) === wanted) {
                                    currentIndex = i
                                    return
                                }
                            }
                            currentIndex = 0
                        }

                        onActivated: {
                            if (!model || currentIndex < 0 || currentIndex >= model.length)
                                return
                            var selected = String(model[currentIndex] || "default")
                            win.voiceDeviceSelected = selected
                            if (win.controllerReady)
                                hudController.set_voice_device(selected)
                            win._showToast("Done: voice input device updated")
                        }
                        onModelChanged: syncIndex()
                        Component.onCompleted: syncIndex()

                        background: Rectangle {
                            radius: theme.radiusSm
                            color: theme.bgSolid
                            border.width: 1
                            border.color: theme.borderSoft
                        }
                        contentItem: Text {
                            text: voiceDeviceCombo.displayText
                            color: theme.textSecondary
                            leftPadding: 8
                            verticalAlignment: Text.AlignVCenter
                            elide: Text.ElideRight
                            font.pixelSize: 12
                        }
                    }

                    Button {
                        objectName: "hudV2VoiceRefreshDevicesButton"
                        text: "Refresh Devices"
                        onClicked: {
                            win._refreshVoiceDevices()
                            win._showToast("Done: voice devices refreshed")
                        }
                        background: Rectangle {
                            radius: theme.radiusSm
                            color: theme.bgSolid
                            border.width: 1
                            border.color: theme.borderSoft
                        }
                        contentItem: Text {
                            text: parent.text
                            color: theme.textSecondary
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                            font.pixelSize: 11
                        }
                    }
                }

                Label {
                    Layout.fillWidth: true
                    text: "Last Transcript"
                    color: theme.textSecondary
                    font.bold: true
                }

                Label {
                    Layout.fillWidth: true
                    text: win.controllerReady ? String(hudController.voiceLastTranscript || "No transcript yet.") : "Voice controller unavailable."
                    color: theme.textMuted
                    wrapMode: Label.Wrap
                }

                Label {
                    Layout.fillWidth: true
                    text: "Last Spoken Output"
                    color: theme.textSecondary
                    font.bold: true
                }

                Label {
                    Layout.fillWidth: true
                    text: win.controllerReady ? String(hudController.voiceLastSpokenText || "No spoken output yet.") : "No spoken output yet."
                    color: theme.textMuted
                    wrapMode: Label.Wrap
                }
            }
        }
    }
}
