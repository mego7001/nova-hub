import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Popup {
    id: root

    property var theme
    property var commands: [
        { id: "mode.general", label: "Switch Mode: general", shortcut: "", actionKind: "switch_mode", payload: { mode: "general" } },
        { id: "mode.3d", label: "Switch Mode: gen_3d_step", shortcut: "", actionKind: "switch_mode", payload: { mode: "gen_3d_step" } },
        { id: "mode.2d", label: "Switch Mode: gen_2d_dxf", shortcut: "", actionKind: "switch_mode", payload: { mode: "gen_2d_dxf" } },
        { id: "drawer.tools", label: "Open Drawer: Tools", shortcut: "", actionKind: "open_drawer", payload: { drawer: "tools" } },
        { id: "drawer.attach", label: "Open Drawer: Attach", shortcut: "", actionKind: "open_drawer", payload: { drawer: "attach" } },
        { id: "drawer.health", label: "Open Drawer: Health", shortcut: "", actionKind: "open_drawer", payload: { drawer: "health" } },
        { id: "drawer.history", label: "Open Drawer: History", shortcut: "", actionKind: "open_drawer", payload: { drawer: "history" } },
        { id: "drawer.voice", label: "Open Drawer: Voice", shortcut: "", actionKind: "open_drawer", payload: { drawer: "voice" } },
        { id: "doctor.report", label: "Run Doctor Report", shortcut: "", actionKind: "run_doctor", payload: ({}) },
        { id: "apply.queue", label: "Queue Apply Candidate", shortcut: "", actionKind: "apply_queue", payload: ({}) },
        { id: "apply.confirm", label: "Confirm Pending Candidate", shortcut: "", actionKind: "apply_confirm", payload: ({}) },
        { id: "apply.reject", label: "Reject Pending Candidate", shortcut: "", actionKind: "apply_reject", payload: ({}) },
        { id: "security.audit", label: "Run Security Audit", shortcut: "", actionKind: "security_audit", payload: ({}) },
        { id: "timeline.refresh", label: "Refresh Timeline", shortcut: "", actionKind: "refresh_timeline", payload: ({}) },
        { id: "voice.toggle", label: "Voice: Toggle Mic", shortcut: "", actionKind: "voice_toggle", payload: ({}) },
        { id: "voice.mute", label: "Voice: Toggle Mute", shortcut: "", actionKind: "voice_mute_toggle", payload: ({}) },
        { id: "voice.stop", label: "Voice: Stop Speaking", shortcut: "", actionKind: "voice_stop", payload: ({}) },
        { id: "voice.replay", label: "Voice: Replay Last", shortcut: "", actionKind: "voice_replay", payload: ({}) },
        { id: "app.minimize", label: "Window: Minimize Nova", shortcut: "", actionKind: "app_minimize", payload: ({}) },
        { id: "app.close", label: "Window: Close Nova", shortcut: "", actionKind: "app_close", payload: ({}) }
    ]
    property var filteredCommands: []
    property int selectedIndex: 0

    signal commandTriggered(var command)

    modal: true
    focus: true
    closePolicy: Popup.NoAutoClose
    width: Math.min(760, Overlay.overlay ? Overlay.overlay.width - 48 : 760)
    height: Math.min(520, Overlay.overlay ? Overlay.overlay.height - 48 : 520)
    anchors.centerIn: Overlay.overlay
    padding: 0

    Overlay.modal: Rectangle {
        color: root.theme.bgSolid
        opacity: 0.74
    }

    background: Rectangle {
        radius: root.theme.radiusLg
        color: root.theme.bgGlass
        border.width: 1
        border.color: root.theme.borderHard
    }

    function _matches(command, queryText) {
        var query = String(queryText || "").toLowerCase().trim()
        if (!query.length)
            return true
        var hay = (String(command.label || "") + " " + String(command.actionKind || "")).toLowerCase()
        var terms = query.split(/\s+/)
        for (var i = 0; i < terms.length; i++) {
            if (hay.indexOf(terms[i]) < 0)
                return false
        }
        return true
    }

    function _clampIndex() {
        if (filteredCommands.length <= 0) {
            selectedIndex = 0
            return
        }
        if (selectedIndex < 0)
            selectedIndex = 0
        if (selectedIndex >= filteredCommands.length)
            selectedIndex = filteredCommands.length - 1
    }

    function applyFilter() {
        var out = []
        for (var i = 0; i < commands.length; i++) {
            var command = commands[i]
            if (_matches(command, searchField.text))
                out.push(command)
        }
        filteredCommands = out
        _clampIndex()
    }

    function openPalette(seedText) {
        searchField.text = String(seedText || "")
        applyFilter()
        selectedIndex = 0
        open()
        searchField.forceActiveFocus()
    }

    function closePalette() {
        close()
    }

    function togglePalette() {
        if (visible)
            closePalette()
        else
            openPalette("")
    }

    function executeSelected() {
        if (filteredCommands.length <= 0)
            return
        var command = filteredCommands[selectedIndex]
        if (!command)
            return
        root.commandTriggered(command)
        closePalette()
    }

    onOpened: {
        applyFilter()
        searchField.forceActiveFocus()
    }

    Shortcut {
        sequence: "Esc"
        enabled: root.visible
        onActivated: root.closePalette()
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 12
        spacing: 10

        Label {
            Layout.fillWidth: true
            text: "Command Palette"
            color: root.theme.textPrimary
            font.bold: true
            font.pixelSize: 14
        }

        TextField {
            id: searchField
            Layout.fillWidth: true
            placeholderText: "Search commands"
            color: root.theme.textPrimary
            placeholderTextColor: root.theme.textMuted
            selectionColor: root.theme.accentSoft
            selectedTextColor: root.theme.bgSolid
            background: Rectangle {
                radius: root.theme.radiusMd
                color: root.theme.bgSolid
                border.width: 1
                border.color: root.theme.borderSoft
            }
            onTextChanged: root.applyFilter()
            Keys.onPressed: (event) => {
                if (event.key === Qt.Key_Down) {
                    root.selectedIndex = Math.min(root.selectedIndex + 1, root.filteredCommands.length - 1)
                    commandList.currentIndex = root.selectedIndex
                    event.accepted = true
                } else if (event.key === Qt.Key_Up) {
                    root.selectedIndex = Math.max(root.selectedIndex - 1, 0)
                    commandList.currentIndex = root.selectedIndex
                    event.accepted = true
                } else if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter) {
                    root.executeSelected()
                    event.accepted = true
                } else if (event.key === Qt.Key_Escape) {
                    root.closePalette()
                    event.accepted = true
                }
            }
        }

        Rectangle {
            Layout.fillWidth: true
            Layout.fillHeight: true
            radius: root.theme.radiusMd
            color: root.theme.bgSolid
            border.width: 1
            border.color: root.theme.borderSoft

            ListView {
                id: commandList
                anchors.fill: parent
                anchors.margins: 6
                clip: true
                spacing: 6
                model: root.filteredCommands
                currentIndex: root.selectedIndex
                onCurrentIndexChanged: root.selectedIndex = currentIndex

                delegate: Rectangle {
                    required property int index
                    required property var modelData

                    width: ListView.view.width
                    height: 56
                    radius: root.theme.radiusSm
                    color: ListView.isCurrentItem ? root.theme.glowSoft : root.theme.bgGlass
                    border.width: 1
                    border.color: ListView.isCurrentItem ? root.theme.borderHard : root.theme.borderSoft

                    Column {
                        anchors.fill: parent
                        anchors.margins: 8
                        spacing: 3

                        Label {
                            width: parent.width
                            text: modelData.label
                            color: root.theme.textPrimary
                            elide: Label.ElideRight
                            font.bold: true
                        }
                        Label {
                            width: parent.width
                            text: String(modelData.actionKind || "")
                            color: root.theme.textMuted
                            elide: Label.ElideRight
                            font.pixelSize: 11
                        }
                    }

                    MouseArea {
                        anchors.fill: parent
                        onClicked: {
                            root.selectedIndex = index
                            commandList.currentIndex = index
                        }
                        onDoubleClicked: root.executeSelected()
                    }
                }
            }
        }

        Label {
            Layout.fillWidth: true
            text: "Enter execute | Esc close"
            color: root.theme.textMuted
            font.pixelSize: 11
            horizontalAlignment: Text.AlignRight
        }
    }
}
