import QtQuick

QtObject {
    id: theme

    property color bgGlass: "#CC1B1510"
    property color bgSolid: "#0D0A08"

    property color textPrimary: "#F8E9CF"
    property color textSecondary: "#DFC79D"
    property color textMuted: "#AA8A5D"

    property color accentPrimary: "#E3A33B"
    property color accentSecondary: "#B26B2B"
    property color accentSoft: "#F0C879"

    property color borderSoft: "#6E532B"
    property color borderHard: "#B8893E"

    property color dangerMuted: "#A65A49"
    property color successMuted: "#5F865C"

    property color glowSoft: "#33E3A33B"
    property color glowStrong: "#55E3A33B"

    property int radiusSm: 6
    property int radiusMd: 10
    property int radiusLg: 14

    property int animFastMs: 120
    property int animMedMs: 180
}