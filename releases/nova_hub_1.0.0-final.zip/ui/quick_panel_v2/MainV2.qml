import QtQuick
import QtQuick.Controls
import QtQuick.Dialogs
import QtQuick.Layouts
import QtQuick.Window
import "../common_ui" as Common
import "../hud_qml_v2/components"

Window {
    id: win

    visible: true
    width: 1180
    height: 760
    minimumWidth: 920
    minimumHeight: 560
    color: "transparent"
    title: "Nova Quick Panel V2"

    function _resolveController() {
        if (typeof quickPanelController !== "undefined" && quickPanelController)
            return quickPanelController
        if (typeof hudController !== "undefined" && hudController)
            return hudController
        return null
    }

    property var controller: _resolveController()
    property bool controllerReady: controller !== null
    property string statusState: "idle"
    property bool waitingAssistant: false

    function _showToast(text) {
        toast.showToast(String(text || "Done"))
    }

    function _appClose() {
        win.close()
    }

    function _appMinimize() {
        win.showMinimized()
    }

    function _markDoneSoon() {
        statusDoneTimer.restart()
    }

    function _runPaletteCommand(command) {
        if (!command || !command.actionKind)
            return
        var action = String(command.actionKind || "")
        var localOnly = action === "app_minimize" || action === "app_close"
        if (!win.controllerReady && !localOnly) {
            _showToast("Controller not ready")
            return
        }
        if (action === "switch_mode") {
            if (command.payload && command.payload.mode)
                win.controller.setTaskMode(command.payload.mode)
            _showToast("Done: switched mode")
            return
        }
        if (action === "run_doctor") {
            win.controller.refreshHealthStats()
            _showToast("Done: health refreshed")
            return
        }
        if (action === "apply_queue") {
            win.controller.queue_apply()
            _showToast("Done: apply queued")
            return
        }
        if (action === "apply_confirm") {
            win.controller.confirm_pending()
            _showToast("Done: pending confirmed")
            return
        }
        if (action === "apply_reject") {
            win.controller.reject_pending()
            _showToast("Done: pending rejected")
            return
        }
        if (action === "security_audit") {
            win.controller.run_security_audit()
            _showToast("Done: security audit started")
            return
        }
        if (action === "refresh_timeline") {
            win.controller.refresh_timeline()
            _showToast("Done: timeline refreshed")
            return
        }
        if (action === "voice_toggle") {
            win.controller.toggle_voice_enabled()
            return
        }
        if (action === "voice_mute_toggle") {
            if (win.controller.voiceMuted)
                win.controller.voice_unmute()
            else
                win.controller.voice_mute()
            return
        }
        if (action === "voice_stop") {
            win.controller.voice_stop_speaking()
            return
        }
        if (action === "voice_replay") {
            win.controller.voice_replay_last()
            return
        }
        if (action === "app_minimize") {
            _appMinimize()
            return
        }
        if (action === "app_close")
            _appClose()
    }

    Common.Theme {
        id: theme
    }

    Shortcut {
        sequence: "Ctrl+K"
        onActivated: commandPalette.togglePalette()
    }

    Shortcut {
        sequence: "Esc"
        onActivated: {
            if (commandPalette.visible)
                commandPalette.closePalette()
        }
    }

    Shortcut {
        sequence: "Ctrl+Q"
        onActivated: win._appClose()
    }

    Shortcut {
        sequence: "Ctrl+W"
        onActivated: win._appClose()
    }

    Timer {
        id: statusDoneTimer
        interval: 850
        repeat: false
        onTriggered: {
            if (win.waitingAssistant)
                return
            win.statusState = "done"
        }
    }

    Connections {
        target: win.controllerReady ? win.controller : null
        function onBusyChanged() {
            if (!win.controllerReady)
                return
            if (win.controller.busy)
                win.statusState = "thinking"
        }
    }

    Rectangle {
        anchors.fill: parent
        radius: theme.radiusLg
        color: theme.bgSolid
        border.width: 1
        border.color: theme.borderSoft

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 12
            spacing: 10

            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 58
                radius: theme.radiusMd
                color: theme.bgGlass
                border.width: 1
                border.color: theme.borderHard

                RowLayout {
                    anchors.fill: parent
                    anchors.margins: 10
                    spacing: 8

                    Label {
                        Layout.fillWidth: true
                        text: "Quick Panel V2 | Ctrl+K Palette | Status: " + (win.controllerReady ? win.controller.statusText : "initializing")
                        color: theme.textPrimary
                        elide: Label.ElideRight
                        font.bold: true
                    }
                    Label {
                        text: win.controllerReady ? ("Mode: " + win.controller.currentTaskMode) : "Mode: n/a"
                        color: theme.textMuted
                    }
                    Button {
                        objectName: "quickPanelV2TopMinimizeButton"
                        text: "Minimize"
                        onClicked: win._appMinimize()
                    }
                    Button {
                        objectName: "quickPanelV2TopCloseButton"
                        text: "Close Nova"
                        onClicked: win._appClose()
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                spacing: 10

                Rectangle {
                    Layout.preferredWidth: 320
                    Layout.fillHeight: true
                    radius: theme.radiusMd
                    color: theme.bgGlass
                    border.width: 1
                    border.color: theme.borderSoft

                    ColumnLayout {
                        anchors.fill: parent
                        anchors.margins: 10
                        spacing: 8

                        Label {
                            text: "Runtime Controls"
                            color: theme.textPrimary
                            font.bold: true
                        }

                        RowLayout {
                            Layout.fillWidth: true
                            Button {
                                Layout.fillWidth: true
                                text: "Queue Apply"
                                onClicked: {
                                    if (!win.controllerReady)
                                        return
                                    win.controller.queue_apply()
                                }
                            }
                            Button {
                                Layout.fillWidth: true
                                text: "Confirm"
                                enabled: win.controllerReady ? win.controller.hasPendingApproval : false
                                onClicked: {
                                    if (win.controllerReady)
                                        win.controller.confirm_pending()
                                }
                            }
                            Button {
                                Layout.fillWidth: true
                                text: "Reject"
                                enabled: win.controllerReady ? win.controller.hasPendingApproval : false
                                onClicked: {
                                    if (win.controllerReady)
                                        win.controller.reject_pending()
                                }
                            }
                        }

                        RowLayout {
                            Layout.fillWidth: true
                            Button {
                                Layout.fillWidth: true
                                text: "Refresh Health"
                                onClicked: {
                                    if (win.controllerReady)
                                        win.controller.refreshHealthStats()
                                }
                            }
                            Button {
                                Layout.fillWidth: true
                                text: "Refresh Ollama"
                                onClicked: {
                                    if (win.controllerReady)
                                        win.controller.refreshOllamaModels()
                                }
                            }
                        }

                        Label {
                            Layout.fillWidth: true
                            wrapMode: Text.WordWrap
                            color: theme.textSecondary
                            text: win.controllerReady ? win.controller.ollamaHealthSummary : "Local LLM status unavailable."
                        }

                        Label {
                            Layout.fillWidth: true
                            wrapMode: Text.WordWrap
                            color: theme.textSecondary
                            text: win.controllerReady ? win.controller.healthStatsSummary : "Health stats unavailable."
                        }

                        Label {
                            Layout.fillWidth: true
                            wrapMode: Text.WordWrap
                            color: theme.textSecondary
                            text: win.controllerReady ? ("Pending: " + (win.controller.hasPendingApproval ? win.controller.confirmationSummary : "none")) : "Pending: n/a"
                        }

                        Item {
                            Layout.fillHeight: true
                        }
                    }
                }

                ChatPane {
                    id: chatPane
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    theme: theme
                    model: win.controllerReady ? win.controller.messagesModel : []
                    busy: win.controllerReady ? win.controller.busy : false
                    currentTaskMode: win.controllerReady ? win.controller.currentTaskMode : "general"
                    taskModesModel: win.controllerReady ? win.controller.taskModesModel : []
                    statusState: win.statusState
                    voiceEnabled: win.controllerReady ? win.controller.voiceEnabled : false
                    voiceMuted: win.controllerReady ? win.controller.voiceMuted : false
                    voiceState: win.controllerReady ? win.controller.voiceState : "disabled"
                    voiceStatusLine: win.controllerReady ? win.controller.voiceStatusLine : "Voice: unavailable"
                    voiceReplayAvailable: win.controllerReady ? String(win.controller.voiceLastSpokenText || "").length > 0 : false
                    onSendRequested: function(message) {
                        if (!win.controllerReady)
                            return
                        win.statusState = "thinking"
                        win.waitingAssistant = true
                        win.controller.send_message(message)
                    }
                    onAttachRequested: attachDialog.open()
                    onToolsRequested: {
                        if (win.controllerReady)
                            win.controller.toggleToolsMenu()
                    }
                    onTaskModeChangedRequested: function(modeId) {
                        if (win.controllerReady)
                            win.controller.setTaskMode(modeId)
                    }
                    onVoiceToggleRequested: {
                        if (win.controllerReady)
                            win.controller.toggle_voice_enabled()
                    }
                    onVoiceMuteToggleRequested: {
                        if (!win.controllerReady)
                            return
                        if (win.controller.voiceMuted)
                            win.controller.voice_unmute()
                        else
                            win.controller.voice_mute()
                    }
                    onVoiceStopRequested: {
                        if (win.controllerReady)
                            win.controller.voice_stop_speaking()
                    }
                    onVoiceReplayRequested: {
                        if (win.controllerReady)
                            win.controller.voice_replay_last()
                    }
                    onVoicePanelRequested: win._showToast("Voice controls available in composer actions")
                    onMessageObserved: function(payload) {
                        if (!payload)
                            return
                        var role = String(payload.role || "")
                        if (role !== "assistant")
                            return
                        win.waitingAssistant = false
                        win._markDoneSoon()
                    }
                }
            }
        }
    }

    CommandPalette {
        id: commandPalette
        theme: theme
        onCommandTriggered: function(command) {
            win._runPaletteCommand(command)
        }
    }

    Toast {
        id: toast
        theme: theme
        z: 100
    }

    FileDialog {
        id: attachDialog
        title: "Attach Files"
        fileMode: FileDialog.OpenFiles
        onAccepted: {
            if (!win.controllerReady)
                return
            win.controller.attachFiles(selectedFiles)
            win._showToast("Done: files attached")
        }
    }
}
