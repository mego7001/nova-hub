from __future__ import annotations

from pathlib import Path


def test_launch_whatsapp_uses_quick_panel_window_path() -> None:
    root = Path(__file__).resolve().parents[1]
    text = (root / "main.py").read_text(encoding="utf-8")

    assert "from ui.quick_panel.app import QuickPanelWindow" in text
    assert "window = QuickPanelWindow(project_root=base_dir)" in text
    assert "from ui.quick_panel.app import main as whatsapp_main" not in text
