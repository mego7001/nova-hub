from pathlib import Path


def test_hud_v2_drawers_cover_core_capabilities() -> None:
    root = Path(__file__).resolve().parents[1]
    text = (root / "ui" / "hud_qml_v2" / "MainV2.qml").read_text(encoding="utf-8")

    assert "{ id: \"tools\", title: \"Tools\" }" in text
    assert "{ id: \"attach\", title: \"Attach\" }" in text
    assert "{ id: \"health\", title: \"Health\" }" in text
    assert "{ id: \"history\", title: \"History\" }" in text
    assert "{ id: \"voice\", title: \"Voice\" }" in text

    assert "Queue Apply Candidate" in text
    assert "Confirm Pending" in text
    assert "Reject Pending" in text
    assert "Run Security Audit" in text
    assert "hudController.queue_apply()" in text
    assert "hudController.confirm_pending()" in text
    assert "hudController.reject_pending()" in text
    assert "hudController.run_security_audit()" in text

    assert "Attach Files" in text
    assert "hudController.attachFiles(selectedFiles)" in text
    assert "hudController.attachLastSummary" in text

    assert "Refresh Health" in text
    assert "Doctor Report" in text
    assert "Local LLM: Ollama" in text
    assert "Refresh Models" in text
    assert "hudController.healthStatsModel" in text
    assert "hudController.healthStatsSummary" in text
    assert "hudController.ollamaHealthSummary" in text
    assert "hudController.ollamaAvailableModels" in text

    assert "Refresh Timeline" in text
    assert "hudController.timelineModel" in text
    assert "hudController.timelineSummary" in text
    assert "hudController.latestReplyPreview" in text
    assert "Capabilities: Chat | Tools | Attach | Health | History | Voice | Security | Timeline" in text
    assert 'objectName: "hudV2TopMinimizeButton"' in text
    assert 'objectName: "hudV2TopCloseButton"' in text


def test_hud_v2_palette_includes_voice_and_apply_actions() -> None:
    root = Path(__file__).resolve().parents[1]
    palette = (root / "ui" / "hud_qml_v2" / "components" / "CommandPalette.qml").read_text(encoding="utf-8")

    assert "drawer.voice" in palette
    assert "apply.queue" in palette
    assert "apply.confirm" in palette
    assert "apply.reject" in palette
    assert "security.audit" in palette
    assert "voice.toggle" in palette
    assert "voice.mute" in palette
    assert "voice.stop" in palette
    assert "voice.replay" in palette
    assert "app.minimize" in palette
    assert "app.close" in palette
