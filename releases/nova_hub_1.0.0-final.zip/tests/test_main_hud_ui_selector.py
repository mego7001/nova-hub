from __future__ import annotations

import sys

import main as cli_main
from ui.hud_qml import app_qml


def test_main_hud_cli_passes_ui_selection(monkeypatch) -> None:
    captured: dict[str, str | None] = {}

    def _fake_launch_hud(args=None) -> int:
        captured["ui"] = getattr(args, "ui", None)
        return 0

    monkeypatch.setattr(cli_main, "_launch_hud", _fake_launch_hud)
    monkeypatch.setattr(sys, "argv", ["main.py", "hud", "--ui", "v2"])

    assert cli_main.main() == 0
    assert captured["ui"] == "v2"


def test_main_default_hud_keeps_ui_unspecified(monkeypatch) -> None:
    captured: dict[str, str | None] = {}

    def _fake_launch_hud(args=None) -> int:
        captured["ui"] = getattr(args, "ui", None)
        return 0

    monkeypatch.setattr(cli_main, "_launch_hud", _fake_launch_hud)
    monkeypatch.setattr(sys, "argv", ["main.py"])

    assert cli_main.main() == 0
    assert captured["ui"] is None


def test_app_qml_resolve_ui_version_precedence(monkeypatch) -> None:
    monkeypatch.delenv("NH_UI_VERSION", raising=False)
    monkeypatch.delenv("NH_UI_V2", raising=False)
    assert app_qml._resolve_ui_version() == "auto"

    monkeypatch.setenv("NH_UI_V2", "1")
    assert app_qml._resolve_ui_version() == "v2"

    monkeypatch.setenv("NH_UI_VERSION", "v1")
    assert app_qml._resolve_ui_version() == "v1"
    assert app_qml._resolve_ui_version("v2") == "v2"


def test_app_qml_auto_candidates_try_v2_then_v1() -> None:
    candidates = app_qml._resolve_qml_candidates("auto")
    assert len(candidates) == 2
    assert candidates[0].name == "MainV2.qml"
    assert candidates[1].name == "Main.qml"
