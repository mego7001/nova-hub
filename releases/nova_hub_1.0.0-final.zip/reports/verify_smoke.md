# Verify Smoke Report

Timestamp: 2026-02-09T22:42:34.372274Z
Target Root: D:\nouva hub\nova_hub_v1_release\nova_hub

## Checks
- failed: python -m compileall D:\nouva hub\nova_hub_v1_release\nova_hub
- success: python main.py --list-tools

## Recommendation
- Fix failing checks and re-run verify.smoke.
